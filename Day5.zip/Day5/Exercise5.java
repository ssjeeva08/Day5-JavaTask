package Day5;
import java.util.*;
public class Exercise5 {
	public static void main(String[]args) {
		Vector<String> vectors=new Vector<>();
		vectors.add("101");
		vectors.add("102");
		vectors.add("103");
		vectors.add("104");
		vectors.add("101");
		System.out.println(vectors);
		System.out.println(vectors.size());
		System.out.println(vectors.contains("101"));		
	}
}
