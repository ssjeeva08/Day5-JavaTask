package Day5;
import java.util.*;
public class Exercise6 {
	public static void main(String[]args) {
		HashSet<Integer> set=new HashSet<>();
		set.add(101);
		set.add(102);
		set.add(103);
		set.add(101);
		set.add(104);
		set.add(102);
		System.out.println(set);
	}
}
