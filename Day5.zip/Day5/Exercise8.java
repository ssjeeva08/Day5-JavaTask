package Day5;
import java.util.*;
public class Exercise8 {
	public static void main(String[]args) {
		TreeSet<Integer> set=new TreeSet<>();
		set.add(105);
		set.add(102);
		set.add(109);
		set.add(101);
		set.add(103);
		set.add(102);
		System.out.println(set);
	}
}
