package Day5;
import java.util.*;
public class Exercise3 {
	public static void main(String [] args) {
		LinkedList<String> list=new LinkedList<>();
		list.add("Laptop");
		list.add("Mobile");
		list.add("Headphones");
		list.add("Charger");
		list.add("Tablet");
		System.out.println("Product names: "+list);
		list.addFirst("Ironbox");
		System.out.println("After adding product at first: "+list);
		list.addLast("Heater");
		System.out.println("After adding product at last: "+list);
		list.removeFirst();
		list.removeLast();
		System.out.println("After remove the last product: "+list);
	}
}
