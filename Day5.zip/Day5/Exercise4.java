package Day5;
import java.util.*;
public class Exercise4 {
	public static void main(String[] args) {
		LinkedList<String> list=new LinkedList<>();
		list.add("Dustin");
		list.add("Lucas");
		list.add("Jane");
		list.add("Mike");
		list.add("Max");
		System.out.println(list);
		

		System.out.println(list);
		list.addFirst("Nancy");

		System.out.println(list);
		list.addLast("Jonathan");

		System.out.println(list.getFirst());

		System.out.println(list.getLast());

		list.removeFirst();
		System.out.println(list);

		list.removeLast();
		System.out.println(list);

		System.out.println(list.contains("Max"));
		
		System.out.println(list.size());
		
		System.out.println(list);
	}
}
