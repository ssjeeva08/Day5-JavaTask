package Day5;
import java.util.*;
public class Exercise1 {
	public static void main(String[] args) {
		ArrayList<String> names=new ArrayList<>();
		names.add("Will");
		names.add("Jhon");
		names.add("Bob");
		names.add("Mike");
		names.add("Nancy");
		System.out.println(names);
		
        System.out.println("After Adding Duplicate: " + names);
		names.add("Will");
		
        System.out.println("After Adding Null: " + names);
		names.add(null);
		System.out.println(names.size());
	}
}
