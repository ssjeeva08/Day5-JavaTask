package Day5;
import java.util.*;

class Student implements Comparable<Student> {

    int rollNo;
    String name;
    int mark;

    Student(int rollNo, String name, int mark) {
        this.rollNo = rollNo;
        this.name = name;
        this.mark = mark;
    }

    public int compareTo(Student s) {
        return rollNo - s.rollNo;
    }
}

public class Exercise10 {
    public static void main(String[] args) {

        TreeSet<Student> ts = new TreeSet<>();

        ts.add(new Student(103, "Ravi", 78));
        ts.add(new Student(101, "Arul", 85));
        ts.add(new Student(102, "Priya", 90));

        for(Student s : ts) {
            System.out.println("Roll No: "+s.rollNo + ", Name: " + s.name + ", Mark: " + s.mark);
        }
    }
}