package Day5;
import java.util.*;
public class Exercise2 {
	public static void main(String []args) {
		ArrayList<String> Names=new ArrayList<>();
		Names.add("Dustin");
		Names.add("Bob");
		Names.add("Hopper");
		Names.add("Mike");
		Names.add("Jane");
		System.out.println(Names);
		Names.add(3,"Billy");
		System.out.println("After adding name at specific index: "+Names);

		Names.remove("Hopper");
		System.out.println("After removing one employee: "+Names);
		
		System.out.println("To check whether name exists: "+Names.contains("Jane"));

		System.out.println("To check index of a name: "+Names.indexOf("Mike"));
		
		Names.set(3, "Max");
		System.out.println("Replacing a name: "+Names);
		
		System.out.println("Total employees: "+Names.size());
		
		Names.clear();
		System.out.println("Clearing all employees: "+Names);

	}
}
