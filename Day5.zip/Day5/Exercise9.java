package Day5;
import java.util.*;
public class Exercise9 {
	public static void main(String[]args) {
		TreeSet<Integer> set=new TreeSet<>();
		set.add(99);
		set.add(89);
		set.add(87);
		set.add(76);
		set.add(90);
		set.add(65);
		System.out.println(set);
		System.out.println(set.descendingSet());
		System.out.println(set.first());
		System.out.println(set.last());
		System.out.println(set.contains(76));
		System.out.println(set.lower(80));
		System.out.println(set.ceiling(80));
		System.out.println(set.remove(90));
		System.out.println(set.size());
		
		
	}
}
