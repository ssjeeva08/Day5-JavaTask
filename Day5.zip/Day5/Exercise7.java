package Day5;
import java.util.*;
public class Exercise7 {
	public static void main(String[]args) {
		LinkedHashSet<Integer> set=new LinkedHashSet<>();
		set.add(101);
		set.add(102);
		set.add(103);
		set.add(101);
		set.add(105);
		set.add(101);
		set.add(104);
		System.out.println(set);
	}
}
